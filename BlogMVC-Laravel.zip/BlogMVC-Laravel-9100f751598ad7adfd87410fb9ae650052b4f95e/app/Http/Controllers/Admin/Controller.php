<?php

namespace App\Http\Controllers\Admin;

class Controller extends \App\Http\Controllers\Controller {

}